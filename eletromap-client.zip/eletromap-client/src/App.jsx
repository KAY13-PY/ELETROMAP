import { useState, useEffect, useCallback, useRef } from 'react';
import axios from 'axios';
import './App.css';
import { APIProvider, Map, AdvancedMarker, Pin, InfoWindow, useMap, useMapsLibrary } from '@vis.gl/react-google-maps';

function App() {
  const [postos, setPostos] = useState([]); 
  const [favorites, setFavorites] = useState([]); // CRUD: Read
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPlace, setSelectedPlace] = useState(null); 
  const [placeDetails, setPlaceDetails] = useState(null);
  const [showFavorites, setShowFavorites] = useState(false); // Alternar visualização

  const [userLocation, setUserLocation] = useState(null); 
  const [directionsResult, setDirectionsResult] = useState(null);
  const [nearbyStations, setNearbyStations] = useState([]); 
  const [isFollowing, setIsFollowing] = useState(false);
  const watchIdRef = useRef(null); 
  const [mapCenter, setMapCenter] = useState({ lat: -22.9056, lng: -47.0608 });

  const [filterOpenNow, setFilterOpenNow] = useState(false);
  const [filterFastCharge, setFilterFastCharge] = useState(false);

  // SUA CHAVE CORRETA:
  const REACT_APP_GOOGLE_MAPS_KEY = "AIzaSyBHGet7x2C3tfKz-pF6QG_Z9BEfKKVZ2uQ"; 

  // Carregar Favoritos ao iniciar
  useEffect(() => {
    axios.get('http://localhost:3001/api/favorites')
      .then(res => setFavorites(res.data))
      .catch(e => console.error("Erro backend:", e));
  }, []);

  const handleToggleFavorite = async (posto) => {
    const isFav = favorites.some(f => f.id === posto.id);
    try {
      const res = isFav 
        ? await axios.delete(`http://localhost:3001/api/favorites/${posto.id}`) // CRUD: Delete
        : await axios.post('http://localhost:3001/api/favorites', posto);      // CRUD: Create
      setFavorites(res.data);
    } catch (e) { alert("Erro ao salvar. O backend está rodando?"); }
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchTerm) return;
    setLoading(true); setShowFavorites(false);
    
    const filters = [];
    if (filterOpenNow) filters.push("Abertos agora");
    if (filterFastCharge) filters.push("Carregador Rápido (CCS)");

    try {
      const res = await axios.post('http://localhost:3001/api/search', { query: searchTerm, filters });
      setPostos(res.data);
      if (res.data.length > 0) setMapCenter(res.data[0].location);
    } catch (e) { alert("Erro na busca."); }
    finally { setLoading(false); }
  };

  const toggleFollowMode = () => {
    if (isFollowing) {
      if(watchIdRef.current) navigator.geolocation.clearWatch(watchIdRef.current);
      setIsFollowing(false);
    } else {
      if (navigator.geolocation) {
        watchIdRef.current = navigator.geolocation.watchPosition(
          (pos) => {
            const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
            setUserLocation(loc); setMapCenter(loc);
          },
          () => alert("Erro ao obter localização. Permita o acesso."),
          { enableHighAccuracy: false }
        );
        setIsFollowing(true);
      } else { alert("Navegador sem GPS."); }
    }
  };

  const handleTraceRoute = (dest) => {
    if (!userLocation) return alert("Clique no alvo 🎯 primeiro!");
    setIsFollowing(false);
    setDirectionsResult({ origin: userLocation, destination: dest.location, travelMode: 'DRIVING' });
    axios.post('http://localhost:3001/api/search-along-route', { origin: userLocation, destination: dest.location })
      .then(res => setNearbyStations(res.data));
  };

  const isFavorite = (id) => favorites.some(f => f.id === id);

  return (
    <APIProvider apiKey={REACT_APP_GOOGLE_MAPS_KEY}>
      <div className="App">
        {/* MAPA */}
        <div className="map-container">
          <Map zoom={13} center={mapCenter} mapId="eletromap_style" disableDefaultUI={true} gestureHandling={'greedy'} onClick={() => setSelectedPlace(null)}>
            {/* Pinos */}
            {[...postos, ...nearbyStations].map(p => (
              <AdvancedMarker key={p.id} position={p.location} onClick={() => { setSelectedPlace(p); setPlaceDetails(null); 
                 axios.post('http://localhost:3001/api/place-details', { placeId: p.id }).then(r => setPlaceDetails(r.data)); 
              }}>
                <Pin background={'#EA4335'} glyphColor={'#fff'} borderColor={'#000'} />
              </AdvancedMarker>
            ))}
            {userLocation && <AdvancedMarker position={userLocation} title="Você"><Pin background={'#00D8A3'} glyphColor={'#000'}/></AdvancedMarker>}
            {directionsResult && <DirectionsRendererComponent request={directionsResult} />}
            
            {/* Pop-up */}
            {selectedPlace && (
              <InfoWindow position={selectedPlace.location} pixelOffset={[0, -40]} onCloseClick={() => setSelectedPlace(null)}>
                <div style={{ padding: '5px', minWidth: '200px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <strong style={{fontSize: '1.1em'}}>{selectedPlace.name}</strong>
                    <button onClick={() => handleToggleFavorite(selectedPlace)} style={{ border:'none', background:'none', cursor:'pointer', fontSize:'1.4em' }}>
                      {isFavorite(selectedPlace.id) ? '⭐' : '☆'}
                    </button>
                  </div>
                  <p style={{fontSize:'0.9em'}}>{selectedPlace.address}</p>
                  {placeDetails && placeDetails.formatted_phone_number && <p style={{margin: '5px 0'}}>📞 {placeDetails.formatted_phone_number}</p>}
                  {placeDetails && placeDetails.opening_hours && (
                    <p style={{ color: placeDetails.opening_hours.open_now ? 'green' : 'red', fontWeight: 'bold' }}>
                      {placeDetails.opening_hours.open_now ? 'Aberto agora' : 'Fechado'}
                    </p>
                  )}
                </div>
              </InfoWindow>
            )}
            <MapFollowController isFollowing={isFollowing} mapCenter={mapCenter} onDragStart={() => setIsFollowing(false)} />
          </Map>
          
          <button onClick={toggleFollowMode} className={`map-location-button ${isFollowing ? 'active' : ''}`}>🎯</button>
        </div>

        {/* PAINEL FLUTUANTE */}
        <div className="search-container">
          <h1>EletroMap ⚡</h1>
          <form onSubmit={handleSearch} className="search-form">
            <input value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Ex: Shopping..." />
            <button type="submit" disabled={loading}>{loading ? "..." : "Buscar"}</button>
          </form>
          <div className="filters-container">
            <label><input type="checkbox" checked={filterOpenNow} onChange={e => setFilterOpenNow(e.target.checked)}/> Abertos</label>
            <label><input type="checkbox" checked={filterFastCharge} onChange={e => setFilterFastCharge(e.target.checked)}/> Rápido</label>
          </div>
          <button onClick={() => setShowFavorites(!showFavorites)} style={{ width: '100%', padding: '10px', cursor:'pointer', background: showFavorites ? '#fff3cd' : 'white', border:'1px solid #ddd' }}>
            {showFavorites ? "🔍 Voltar para Resultados" : "⭐ Ver Meus Favoritos"}
          </button>
        </div>

        {/* LISTA DE RESULTADOS OU FAVORITOS */}
        {(postos.length > 0 || favorites.length > 0 || directionsResult) && (
          <div className="results-list">
             {directionsResult ? (
               <>
                <button className="clear-route-button" onClick={() => { setDirectionsResult(null); setNearbyStations([]); }}>Limpar Rota</button>
                <h3>Postos no Caminho</h3>
                <ul>{nearbyStations.map(p => <li key={p.id} onClick={() => setMapCenter(p.location)}>{p.name}</li>)}</ul>
               </>
             ) : showFavorites ? (
               <>
                <h3>Meus Favoritos</h3>
                {favorites.length === 0 && <p>Nenhum favorito salvo.</p>}
                <ul>
                  {favorites.map(p => (
                    <li key={p.id} onClick={() => setMapCenter(p.location)}>
                       <div style={{display:'flex', justifyContent:'space-between'}}>
                         <strong>{p.name}</strong>
                         <span onClick={(e) => {e.stopPropagation(); handleToggleFavorite(p)}} style={{cursor:'pointer'}}>🗑️</span>
                       </div>
                       <p style={{fontSize:'0.8em', margin:0}}>{p.address}</p>
                       <button className="route-button" onClick={(e) => {e.stopPropagation(); handleTraceRoute(p)}}>Rota</button>
                    </li>
                  ))}
                </ul>
               </>
             ) : (
               <>
                <h3>Resultados</h3>
                <ul>
                  {postos.map(p => (
                    <li key={p.id} onClick={() => setMapCenter(p.location)}>
                      <strong>{p.name}</strong>
                      <p style={{fontSize:'0.8em', margin:0}}>{p.address}</p>
                      <button className="route-button" onClick={(e) => {e.stopPropagation(); handleTraceRoute(p)}}>Rota</button>
                    </li>
                  ))}
                </ul>
               </>
             )}
          </div>
        )}
      </div>
    </APIProvider>
  );
}

// Componentes internos (sem alteração lógica, apenas compactados para caber)
function DirectionsRendererComponent({ request }) {
  const map = useMap(); const lib = useMapsLibrary('routes'); const [r, setR] = useState(null);
  useEffect(() => { if (lib && map) setR(new lib.DirectionsRenderer({ map })); }, [lib, map]);
  useEffect(() => { if (r && request) new google.maps.DirectionsService().route({ origin: request.origin, destination: request.destination, travelMode: request.travelMode }, (res, s) => s === 'OK' && r.setDirections(res)); }, [r, request]);
  return null;
}
function MapFollowController({ isFollowing, mapCenter, onDragStart }) {
  const map = useMap();
  useEffect(() => { if (map) { const l = map.addListener('dragstart', onDragStart); return () => l.remove(); } }, [map, onDragStart]);
  useEffect(() => { if (map && isFollowing && mapCenter) map.panTo(mapCenter); }, [map, isFollowing, mapCenter]);
  return null;
}

export default App;